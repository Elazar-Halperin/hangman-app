package com.example.stoper;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    Button btn_stopOrStart, btn_restart;
    TextView tv_stopper;
    FloatingActionButton fab_copyPaste;
    private static final DecimalFormat df = new DecimalFormat("0.00");


    boolean running;

    double seconds;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_restart = findViewById(R.id.btn_restart);
        btn_stopOrStart = findViewById(R.id.btn_stopOrStart);

        tv_stopper = findViewById(R.id.tv_stopper);

        fab_copyPaste = findViewById(R.id.fab_copyPaste);

        running = false;
        seconds = 0;

        setListeners();


        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    while (running) {
                        try {
                            Thread.sleep(10);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        seconds += 0.01;
                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                // Stuff that updates the UI
                                tv_stopper.setText(seconds + "");
                                tv_stopper.setText(formattedString(seconds));
                            }
                        });

                        Log.d("handler", seconds + "");
                    }
                }
            }

        }).start();

    }

    private String formattedString(double time) {
        StringBuilder stringBuilder = new StringBuilder();

        int minutes = (int) (Math.floor(time) / 60);
        time = time - (60 * minutes);

        stringBuilder.append(minutes + ":");

        stringBuilder.append(df.format(time));


        return  stringBuilder.toString();
    }

    private void setListeners() {
        btn_stopOrStart.setOnClickListener(v -> {
            running = !running;
            changeButtonStyle(running);
            Log.d("handler", running + "");
        });

        fab_copyPaste.setOnClickListener( v-> {
            ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            clipboardManager.setPrimaryClip(ClipData.newPlainText("Timer", formattedString(seconds)));

            Toast.makeText(getApplicationContext(), "Copied!", Toast.LENGTH_SHORT).show();
        });

    }

    private void changeButtonStyle(boolean running) {
        if(running) {
            btn_stopOrStart.setText(getString(R.string.stop));
            btn_stopOrStart.getBackground().setColorFilter(getColor( R.color.purple), PorterDuff.Mode.MULTIPLY);
        } else {
            btn_stopOrStart.setText(getString(R.string.start));
            btn_stopOrStart.getBackground().setColorFilter(getColor( R.color.dark_red), PorterDuff.Mode.MULTIPLY);
        }
    }

}