package com.example.jew;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.app.ActionBar;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.QuickContactBadge;
import android.widget.TextView;

import com.example.jew.Fragments.WonDialogFragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.w3c.dom.Text;

import java.sql.ClientInfoStatus;
import java.util.List;

public class ApchiActivity extends AppCompatActivity {

    public static final int LETTERS_IN_ALPHABET = 26;
    public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";

    SharedPreferences sp;

    TextView tv_name;
    TextView tv_guessWord;
    ImageView iv_hangman;

    String word;
    String censoredWord;

    FloatingActionButton fab_logOut;

    LinearLayout ll_keyboard;

    public static final int[] images = new int[]{
            R.drawable.fuck0
            , R.drawable.fuck
            , R.drawable.fuck1_5
            , R.drawable.fuck2
            , R.drawable.fuck3
            , R.drawable.fuck4
            , R.drawable.fuck5};

    int lives;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apchi);

        sp = getApplicationContext().getSharedPreferences(MainActivity.SP_TAG, MODE_PRIVATE);

        String name = sp.getString(MainActivity.NAME, "none");

        ll_keyboard = findViewById(R.id.ll_keyBoard);
        tv_name = findViewById(R.id.tv_name);
        tv_guessWord = findViewById(R.id.tv_guessText);
        iv_hangman = findViewById(R.id.iv_hangman);

        fab_logOut = findViewById(R.id.fab_logOut);

        fab_logOut.setOnClickListener(v-> {
            SharedPreferences.Editor editor = sp.edit();
            editor.putString(MainActivity.NAME, null);
            editor.apply();
            Intent i = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(i);
            finish();
        });

        iv_hangman.setImageDrawable(getDrawable(images[0]));

        tv_name.setText(name);

        lives = 5;
        word = Words.getRandomWord();
        censoredWord = getWordCensored(word);
        tv_guessWord.setText(censoredWord);

        GenerateButtonsToTheLayout();
    }

    private void GenerateButtonsToTheLayout() {
        int count = 0;
        Log.d("wtf?", "wtf");
        for (int i = 0; i < ll_keyboard.getChildCount(); i++) {

            LinearLayout linearLayout = (LinearLayout) ll_keyboard.getChildAt(i);
            for (int j = 0; j < linearLayout.getChildCount(); j++) {

                Button btn = (Button) linearLayout.getChildAt(j);
                btn.setText(String.valueOf(ALPHABET.charAt(count)));

                btn.setOnClickListener(v -> {
                    if(lives <= 0) {
                    return;
                }
                    btn.setEnabled(false);
                    btn.setBackgroundColor(getResources().getColor(R.color.red));

                    boolean exist = tooLazyToNameTheFunction(btn.getText().toString());

                    if (!exist) {
                        lives--;
                        iv_hangman.setImageDrawable(getDrawable(images[6 - lives]));

                    } else {
                        checkIfWon();
                    }
                });
                count++;
            }
        }
    }

    private String getWordCensored(String text) {
        String censor = "";
        for (int i = 0; i < text.length(); i++) {
            if(text.charAt(i) == ' ') {
                censor += " ";
                continue;
            }
            censor += "_";
        }

        return censor;
    }

    private void checkIfWon() {
        if(censoredWord.equals(word)) {
            WonDialogFragment dialog = new WonDialogFragment();
            dialog.show(getSupportFragmentManager(), "MyFragment");
        }
    }

    private boolean tooLazyToNameTheFunction(String c) {
        StringBuilder stringBuilder = new StringBuilder(censoredWord);
        int count = 0;
        for (int i = 0; i < word.length(); i++) {
            if (String.valueOf(word.charAt(i)).equals(c)) {
                stringBuilder.setCharAt(i, word.charAt(i));
                count++;
            }
        }
        censoredWord = String.valueOf(stringBuilder);
        updateTextView();

        return count > 0;
    }

    private void updateTextView() {
        tv_guessWord.setText(censoredWord);
    }


}