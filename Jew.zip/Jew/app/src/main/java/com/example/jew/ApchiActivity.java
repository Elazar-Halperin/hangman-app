package com.example.jew;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.jew.Fragments.WonDialogFragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class ApchiActivity extends AppCompatActivity {


    public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
    public static final String SCORE = "score";

    SharedPreferences sp;

    TextView tv_name;
    TextView tv_guessWord;
    ImageView iv_hangman;

    String word;
    String censoredWord;
    Boolean isWon;

    int currentIndex;
    List<String> words;
    int score;

    WonDialogFragment dialogFragment;

    FloatingActionButton fab_logOut;

    LinearLayout ll_keyboard;

    public static final int[] images = new int[]{
            R.drawable.fuck0
            , R.drawable.fuck
            , R.drawable.fuck1_5
            , R.drawable.fuck2
            , R.drawable.fuck3
            , R.drawable.fuck4
            , R.drawable.fuck5};

    int lives;
    private String text;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apchi);

        sp = getApplicationContext().getSharedPreferences(MainActivity.SP_TAG, MODE_PRIVATE);
        dialogFragment = new WonDialogFragment();

        String name = sp.getString(MainActivity.NAME, "none");

        ll_keyboard = findViewById(R.id.ll_keyBoard);
        tv_name = findViewById(R.id.tv_name);
        tv_guessWord = findViewById(R.id.tv_guessText);
        iv_hangman = findViewById(R.id.iv_hangman);

        fab_logOut = findViewById(R.id.fab_logOut);

        isWon = false;

        currentIndex = 0;
        score = 0;
        words = Words.getListOfEasyWords();

        lives = 5;
        word = words.get(currentIndex);
        censoredWord = getWordCensored(word);
        tv_guessWord.setText(censoredWord);

        iv_hangman.setImageDrawable(getDrawable(images[0]));

        tv_name.setText(name);
        Log.d("word", word);

        setListeners();
        setLinearLayoutsButtonsListeners();
    }

    private void setListeners() {

        fab_logOut.setOnClickListener(v -> {
            SharedPreferences.Editor editor = sp.edit();
            editor.putString(MainActivity.NAME, null);
            editor.apply();
            finishThisActivity(MainActivity.class);
        });

    }

    private void checkIfWon() {
        if (censoredWord.equals(word)) {
            isWon = true;
        }
    }

    /**
     * the function gets string with one character and checks if the characters exists
     * in the word that the client is guessing.
     * if the word exists then it will change the censored word and update it.
     *
     * @param character - string with one character.
     * @return true, if the character exists, otherwise false.
     */
    private boolean tooLazyToNameTheFunction(String character) {
        StringBuilder stringBuilder = new StringBuilder(censoredWord);
        int count = 0;
        for (int i = 0; i < word.length(); i++) {
            if (String.valueOf(word.charAt(i)).equals(character)) {
                stringBuilder.setCharAt(i, word.charAt(i));
                count++;
            }
        }
        censoredWord = String.valueOf(stringBuilder);
        updateGuessWordTV();

        return count > 0;
    }

    private void updateGuessWordTV() {
        tv_guessWord.setText(censoredWord);
    }


    /**
     * The function gets string object, and returns the string censored
     * for example the function receives the word "hello" the function returns "_____"
     */
    private String getWordCensored(String text) {
        this.text = text;
        String censor = "";
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == ' ') {
                censor += " ";
                continue;
            }
            censor += "_";
        }

        return censor;
    }

    @SuppressLint("UseCompatLoadingForDrawables") // just to avoid annoying warning.
    private void nextWordOrTryAgain() {



        // if the client won then add plus one to the score
        // if the use lost, then deduct one, in case the score is 0, then do nothing,
        // also whe should check if we are on the first word, if we are then add if won:
        currentIndex += isWon ? 1 : 0;
        lives = 5;
        isWon = false;
        word = words.get(currentIndex);
        censoredWord = getWordCensored(word);
        iv_hangman.setImageDrawable(getDrawable(images[0]));

        Log.d("word", word);

        setEnabledToEachButton(true);
        updateGuessWordTV();
    }

    /**
     * Function the enables or disables all the keyboard buttons.
     * @param enabled - boolean.
     *
     */
    private void setEnabledToEachButton(boolean enabled) {
        for (int i = 0; i < ll_keyboard.getChildCount(); i++) {

            LinearLayout linearLayout = (LinearLayout) ll_keyboard.getChildAt(i);
            for (int j = 0; j < linearLayout.getChildCount(); j++) {
                Button btn = ((Button) linearLayout.getChildAt(j));
                btn.setEnabled(enabled);

                btn.setBackgroundColor(getResources().getColor(enabled ? R.color.green_won_dialog_background : R.color.red_loose_dialog_background));
            }
        }
    }

    private void setLinearLayoutsButtonsListeners() {
        int count = 0;
        Log.d("wtf?", "wtf");
        for (int i = 0; i < ll_keyboard.getChildCount(); i++) {

            LinearLayout linearLayout = (LinearLayout) ll_keyboard.getChildAt(i);
            for (int j = 0; j < linearLayout.getChildCount(); j++) {

                Button btn = (Button) linearLayout.getChildAt(j);
                btn.setText(String.valueOf(ALPHABET.charAt(count)));

                btn.setOnClickListener(v -> {
                    btn.setEnabled(false);
                    btn.setBackgroundColor(getResources().getColor(R.color.red));

                    performKeyboardButtonClicked(btn.getText().toString().trim());
                });
                count++;
            }
        }
    }

    private void showDialog() {
        if(!dialogFragment.isAdded() && !dialogFragment.isVisible()) {
            score += isWon ? 1 : score == 0 ? 0 : -1;

            boolean isLastWord = currentIndex >= words.size() - 1;

            if(isLastWord && isWon) {
                Intent i = new Intent(getApplicationContext(), WonActivity.class);
                i.putExtra(SCORE, score);
                startActivity(i);
                finish();
                return;
            }
            dialogFragment.putScore(score);
            dialogFragment.show(getSupportFragmentManager(), isWon ? WonDialogFragment.WON_TAG : WonDialogFragment.LOST_TAG);
            dialogFragment.setListener(this::nextWordOrTryAgain);
        }
    }

    private void performKeyboardButtonClicked(String buttonText) {
        boolean exist = tooLazyToNameTheFunction(buttonText);

        if (!exist) {
            lives--;
            iv_hangman.setImageDrawable(getDrawable(images[6 - lives]));

        } else {
            checkIfWon();
        }

        if (isWon || lives <= 0) {
            showDialog();
        }
    }

    /**
     * @param cls - the activity that we want to transfer into.
     * the function will transfer us into @param cls activity
     * and will finish his current activity.
     */
    private void finishThisActivity(Class<?> cls) {
        Intent intent = new Intent(getApplicationContext(), cls);
        startActivity(intent);
        finish();
    }
}