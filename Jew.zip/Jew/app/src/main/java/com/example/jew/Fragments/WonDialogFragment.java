package com.example.jew.Fragments;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;

import com.example.jew.ApchiActivity;
import com.example.jew.MainActivity;
import com.example.jew.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class WonDialogFragment extends DialogFragment {

    public static final String WON_TAG = "won";
    public static final String LOST_TAG = "lost";
    int score;

    Bundle bundle = new Bundle();
    DialogDismissed mListener;
    TextView tv_score;
    Button btn_tryAgain;

    public void putScore(int score) {

        bundle.putInt(ApchiActivity.SCORE, score);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Dialog dialog = new Dialog(getActivity(), R.style.CustomDatePickerDialog);
        String tag = getTag();

        int layout;
        if(tag.equals(WON_TAG)) {
            layout = R.layout.won_fragment;
        } else {
            layout = R.layout.lose_fragment;
        }

        int score = bundle.getInt(ApchiActivity.SCORE, 0);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(layout);
        dialog.setTitle("fuck");

        Window window = dialog.getWindow();
        WindowManager.LayoutParams params = window.getAttributes();
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;
        params.windowAnimations =  R.style.DialogAnimation;

        btn_tryAgain = dialog.findViewById(R.id.btn_tryAgain);
        tv_score = dialog.findViewById(R.id.tv_score);

        tv_score.setText("Score: " + score);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setAttributes(params);

        btn_tryAgain.setOnClickListener( v -> {
            dismiss();
        });
        // prevent user from quiting the dialog when back pressing.
        dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                return true;
            }
        });

        return dialog;
    }


    // creating the on dismiss functionality
    public interface DialogDismissed {
         void onDialogDismissed();
    }

    public void setListener(DialogDismissed listener) {
        mListener = listener;
    }

    @Override
    public void onDismiss(@NonNull DialogInterface dialog) {
        super.onDismiss(dialog);
        if(mListener != null) {
            mListener.onDialogDismissed();
        }
    }
}
