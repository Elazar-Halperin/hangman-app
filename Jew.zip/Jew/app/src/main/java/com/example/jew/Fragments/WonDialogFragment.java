package com.example.jew.Fragments;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.example.jew.R;

public class WonDialogFragment extends DialogFragment {

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Dialog dialog = new Dialog(getActivity().getApplicationContext(), R.style.CustomDatePickerDialog);
        dialog.requestWindowFeature(STYLE_NO_TITLE);
        dialog.setContentView(R.layout.won_fragment);

        return dialog;
    }
}
