package com.example.jew;

public class Words {

     static final String[] words = new String[] {"move", "hello", "free"};

    public static String getRandomWord() {
        int length = words.length;

        int randomIndex = (int) Math.floor(Math.random() * length);

        return words[randomIndex];
    }

}
