package com.example.jew;

import android.util.Log;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Words {

    static final String[] words = new String[]{"move", "hello", "free", "accept", "basketball", "excellent", "mist", "cheerful", "vague", "black and white"};

    public static String getRandomWord() {
        int length = words.length;

        int randomIndex = (int) Math.floor(Math.random() * length);

        return words[randomIndex];
    }

    public static List<String> getListOfRandomizeWords() {
        List<String> list = Arrays.asList(words);
        Collections.shuffle(list);
        Log.d("words", list.toString());
        return list;
    }
}
