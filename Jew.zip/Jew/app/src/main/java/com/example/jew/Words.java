package com.example.jew;

import android.util.Log;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Words {

    static final String[] easyWords = new String[]{"move", "hello", "free", "mist"};
    static final String[] intermediateWords = new String[]{"accept", "excellent", "cheerful", "vague"};
    static final String[] hardWords = new String[]{"basketball", "implication", "accountant", "sympathetic" , "policeman","black and white"};


    public static String getRandomWord() {
        int length = easyWords.length;

        int randomIndex = (int) Math.floor(Math.random() * length);

        return easyWords[randomIndex];
    }

    public static List<String> getListOfEasyWords() {
        List<String> list = Arrays.asList(easyWords);
        Collections.shuffle(list);
        Log.d("words", list.toString());
        return list;
    }
}
