package com.example.jew;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    public static final String NAME = "name";
    public static final String SP_TAG = "sp tag";

    TextInputEditText et_name;
    Button btn_join;

    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sp = getSharedPreferences(SP_TAG, MODE_PRIVATE);
        if (sp.getString(NAME, null) != null) {
            Intent i = new Intent(getApplicationContext(), ApchiActivity.class);
            startActivity(i);
            finish();
            return;
        }

        et_name = findViewById(R.id.et_name);
        btn_join = findViewById(R.id.btn_join);


        btn_join.setOnClickListener(v -> {
            String name = et_name.getText().toString().trim();

            if (name.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Pls provide a name!", Toast.LENGTH_SHORT).show();
                return;
            }

            SharedPreferences.Editor editor = sp.edit();

            editor.putString(NAME, name);
            editor.apply();

            Intent intent = new Intent(getApplicationContext(), ApchiActivity.class);
            startActivity(intent);
            finish();
        });
    }
}