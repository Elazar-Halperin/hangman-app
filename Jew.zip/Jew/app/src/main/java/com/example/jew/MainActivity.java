package com.example.jew;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static final String NAME = "name";
    public static final String SP_TAG = "sp tag";


    TextInputEditText et_name;
    Button btn_join;

    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // When the keyboard is opened then the views will go up!
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        // check if there's already a name in the local SharedPreferences

        sp = getSharedPreferences(SP_TAG, MODE_PRIVATE);
        if (sp.getString(NAME, null) != null) {
            finishThisActivity(ApchiActivity.class);
            return;
        }

        et_name = findViewById(R.id.et_name);
        btn_join = findViewById(R.id.btn_join);

        setListeners();
    }


    private void setListeners() {
        btn_join.setOnClickListener(v -> {
            String name = et_name.getText().toString().trim();

            if (name.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Pls provide a name!", Toast.LENGTH_SHORT).show();
                return;
            }

            addNameIntoSP(NAME, name);

            finishThisActivity(ApchiActivity.class);
        });
    }

    private void addNameIntoSP(String TAG, String name) {
        SharedPreferences.Editor editor = sp.edit();

        editor.putString(TAG, name);
        editor.apply();
    }


    /**
     * @param cls - the activity that we want to transfer into.
     * the function will transfer us into @param cls activity
     * and will finish his current activity.
     */
    private void finishThisActivity(Class<?> cls) {
        Intent intent = new Intent(getApplicationContext(), cls);
        startActivity(intent);
        finish();
    }
}