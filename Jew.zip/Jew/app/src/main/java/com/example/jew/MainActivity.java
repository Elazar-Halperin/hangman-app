package com.example.jew;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "name";

    TextInputEditText et_name;
    Button btn_join;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_name = findViewById(R.id.et_name);
        btn_join = findViewById(R.id.btn_join);

        btn_join.setOnClickListener( v -> {
            String name = et_name.getText().toString().trim();

            if(name.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Pls provide a name!", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(getApplicationContext(), ApchiActivity.class);
            intent.putExtra(TAG, name);
            startActivity(intent);
        });
    }
}