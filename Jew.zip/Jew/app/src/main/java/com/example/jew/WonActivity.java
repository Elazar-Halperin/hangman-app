package com.example.jew;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class WonActivity extends AppCompatActivity {

    public static final String BEST_SCORE = "BestScore";
    SharedPreferences sp;
    TextView tv_name, tv_score, tv_bestScore;

    int score;
    int bestScore;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_won);

        Intent i = getIntent();
        score = i.getIntExtra(ApchiActivity.SCORE, 0);

        sp = getApplicationContext().getSharedPreferences(MainActivity.SP_TAG, MODE_PRIVATE);

        name = sp.getString(MainActivity.NAME, "");

        setBestScore();

        initializeViews();

        setTextViewTexts();
    }

    private void setBestScore() {
        bestScore = sp.getInt(BEST_SCORE, 0);
        if (score > bestScore) {
            bestScore = score;
            SharedPreferences.Editor editor = getSharedPreferences(MainActivity.SP_TAG, MODE_PRIVATE).edit();
            editor.putInt(BEST_SCORE, bestScore);
            editor.apply();
        }
    }

    private void setTextViewTexts() {
        tv_name.setText(name);
        tv_score.setText(String.valueOf(score));
        tv_bestScore.setText(String.valueOf(bestScore));
    }

    private void initializeViews() {
        tv_bestScore = findViewById(R.id.tv_bestScore);
        tv_score = findViewById(R.id.tv_score);
        tv_name = findViewById(R.id.tv_name);
    }
}